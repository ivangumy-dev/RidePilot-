# RidePilot – Masterplan Navigation

## Hauptziel
RidePilot soll direkt nach dem Start gespeicherte Ziele zeigen. Kein Reiseführer-System und keine zusätzlichen Favoriten-Kategorien.

## Navigation
- Ziel antippen
- aktuelle Position bestimmen
- Route automatisch berechnen
- Restdistanz automatisch anzeigen
- Umwege automatisch berücksichtigen
- gefahrene Strecke automatisch zählen

## Reichweite
Die alte manuelle Zielkilometer-Eingabe entfällt.

Berechnung:
`Restreichweite = Startreichweite - tatsächlich gefahrene Kilometer`

## App-Wechsel
Die Navigation darf beim Wechsel zu Spotify, WhatsApp oder Dateien nicht beendet werden.
Beim Zurückkehren wird die aktive Fahrt wieder angezeigt.

## Sicherheit
Andere Apps nur im Stillstand bedienen.
Während der Fahrt bleibt RidePilot auf Navigation und Fahrdaten reduziert.
