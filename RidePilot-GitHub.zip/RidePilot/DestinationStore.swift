import Foundation

enum DestinationStore {
    static let destinations: [RideDestination] = [
        RideDestination(
            name: "Glattzentrum",
            latitude: 47.4080,
            longitude: 8.5950,
            symbol: "bag.fill"
        ),

        // Private Ziele lokal ergänzen.
        // Keine privaten Wohnadressen in ein öffentliches GitHub-Repository committen.
        RideDestination(
            name: "Zuhause",
            latitude: 47.0000,
            longitude: 8.0000,
            symbol: "house.fill"
        ),
        RideDestination(
            name: "Wohnzimmer",
            latitude: 47.0000,
            longitude: 8.0000,
            symbol: "music.note.house.fill"
        ),
        RideDestination(
            name: "Remo",
            latitude: 47.0000,
            longitude: 8.0000,
            symbol: "person.fill"
        ),
        RideDestination(
            name: "Dafi",
            latitude: 47.0000,
            longitude: 8.0000,
            symbol: "person.fill"
        )
    ]
}
