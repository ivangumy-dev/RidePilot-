import SwiftUI

@main
struct RidePilotApp: App {
    @StateObject private var navigation = RideNavigationModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(navigation)
        }
    }
}
