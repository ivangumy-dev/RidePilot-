import Foundation
import CoreLocation
import MapKit

@MainActor
final class RideNavigationModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var activeDestination: RideDestination?
    @Published var route: MKRoute?
    @Published var currentLocation: CLLocation?
    @Published var remainingRouteKm: Double = 0
    @Published var drivenKm: Double = 0
    @Published var remainingRangeKm: Double = 0
    @Published var isRiding = false
    @Published var locationAuthorizationDenied = false

    private let locationManager = CLLocationManager()
    private var lastLocation: CLLocation?
    private var startRangeKm: Double = 0
    private var lastRouteRefresh: Date = .distantPast

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.activityType = .automotiveNavigation
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        locationManager.distanceFilter = 5
        locationManager.pausesLocationUpdatesAutomatically = false
    }

    func requestPermission() {
        locationManager.requestWhenInUseAuthorization()
    }

    func startRide(to destination: RideDestination, startRangeKm: Double) {
        activeDestination = destination
        self.startRangeKm = max(0, startRangeKm)
        remainingRangeKm = self.startRangeKm
        drivenKm = 0
        isRiding = true
        lastLocation = nil

        locationManager.startUpdatingLocation()

        if let coordinate = currentLocation?.coordinate {
            calculateRoute(from: coordinate, to: destination.coordinate)
        }
    }

    func stopRide() {
        locationManager.stopUpdatingLocation()
        activeDestination = nil
        route = nil
        remainingRouteKm = 0
        drivenKm = 0
        isRiding = false
        lastLocation = nil
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        locationAuthorizationDenied =
            manager.authorizationStatus == .denied ||
            manager.authorizationStatus == .restricted

        if manager.authorizationStatus == .authorizedWhenInUse ||
            manager.authorizationStatus == .authorizedAlways {
            manager.startUpdatingLocation()
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let latest = locations.last else { return }

        Task { @MainActor in
            currentLocation = latest

            if isRiding {
                updateDrivenDistance(with: latest)

                if let destination = activeDestination,
                   Date().timeIntervalSince(lastRouteRefresh) > 8 {
                    lastRouteRefresh = Date()
                    calculateRoute(from: latest.coordinate, to: destination.coordinate)
                }
            }
        }
    }

    private func updateDrivenDistance(with current: CLLocation) {
        if let previous = lastLocation {
            let meters = current.distance(from: previous)

            // Grobe GPS-Ausreisser ignorieren.
            if meters > 1, meters < 1000 {
                let km = meters / 1000
                drivenKm += km
                remainingRangeKm = max(0, startRangeKm - drivenKm)
            }
        }

        lastLocation = current
    }

    private func calculateRoute(from source: CLLocationCoordinate2D,
                                to destination: CLLocationCoordinate2D) {
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: source))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: destination))
        request.transportType = .automobile
        request.requestsAlternateRoutes = false

        MKDirections(request: request).calculate { [weak self] response, _ in
            guard let route = response?.routes.first else { return }

            Task { @MainActor in
                self?.route = route
                self?.remainingRouteKm = route.distance / 1000
            }
        }
    }
}
