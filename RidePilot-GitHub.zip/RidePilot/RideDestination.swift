import Foundation
import CoreLocation

struct RideDestination: Identifiable, Hashable {
    let id: UUID
    let name: String
    let latitude: Double
    let longitude: Double
    let symbol: String

    init(id: UUID = UUID(), name: String, latitude: Double, longitude: Double, symbol: String) {
        self.id = id
        self.name = name
        self.latitude = latitude
        self.longitude = longitude
        self.symbol = symbol
    }

    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}
