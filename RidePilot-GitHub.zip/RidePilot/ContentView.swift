import SwiftUI
import MapKit

struct ContentView: View {
    @EnvironmentObject private var navigation: RideNavigationModel
    @State private var startRangeText = "42"

    var body: some View {
        NavigationStack {
            Group {
                if navigation.isRiding {
                    ActiveRideView()
                } else {
                    destinationList
                }
            }
            .navigationTitle(navigation.isRiding ? "Navigation" : "RidePilot")
        }
        .onAppear {
            navigation.requestPermission()
        }
        .alert("Standortzugriff erforderlich",
               isPresented: $navigation.locationAuthorizationDenied) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("RidePilot benötigt Standortzugriff, um Strecke und gefahrene Kilometer automatisch zu berechnen.")
        }
    }

    private var destinationList: some View {
        List {
            Section("Reichweite vor Fahrt") {
                HStack {
                    TextField("z. B. 42", text: $startRangeText)
                        .keyboardType(.decimalPad)
                    Text("km")
                        .foregroundStyle(.secondary)
                }
            }

            Section("Wohin?") {
                ForEach(DestinationStore.destinations) { destination in
                    Button {
                        let normalized = startRangeText.replacingOccurrences(of: ",", with: ".")
                        let range = Double(normalized) ?? 0
                        navigation.startRide(to: destination, startRangeKm: range)
                    } label: {
                        Label(destination.name, systemImage: destination.symbol)
                    }
                }
            }
        }
    }
}

private struct ActiveRideView: View {
    @EnvironmentObject private var navigation: RideNavigationModel

    var body: some View {
        VStack(spacing: 18) {
            Map {
                if let route = navigation.route {
                    MapPolyline(route.polyline)
                        .stroke(.primary, lineWidth: 5)
                }

                if let destination = navigation.activeDestination {
                    Marker(destination.name, coordinate: destination.coordinate)
                }
            }
            .mapControls {
                MapUserLocationButton()
                MapCompass()
            }
            .frame(minHeight: 320)

            VStack(spacing: 8) {
                Text(navigation.activeDestination?.name ?? "")
                    .font(.title.bold())

                Text(String(format: "%.1f km bis Ziel", navigation.remainingRouteKm))
                    .font(.title2)

                HStack {
                    metric(title: "Gefahren", value: navigation.drivenKm)
                    metric(title: "Restreichweite", value: navigation.remainingRangeKm)
                }
            }
            .padding(.horizontal)

            Button("Fahrt beenden", role: .destructive) {
                navigation.stopRide()
            }
            .buttonStyle(.borderedProminent)
            .padding(.bottom)
        }
    }

    private func metric(title: String, value: Double) -> some View {
        VStack {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(String(format: "%.1f km", value))
                .font(.headline)
        }
        .frame(maxWidth: .infinity)
    }
}
