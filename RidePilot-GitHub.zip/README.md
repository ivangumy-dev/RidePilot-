# RidePilot

RidePilot ist eine einfache iPhone-Navigations-App für gespeicherte Ziele und automatische Fahrstrecken-/Reichweitenberechnung.

## Funktionen
- Direktziele wie Zuhause, Glattzentrum, Wohnzimmer, Remo und Dafi
- Route und Entfernung automatisch berechnen
- Tatsächlich gefahrene Kilometer automatisch zählen
- Restreichweite automatisch aktualisieren
- Navigation bleibt beim App-Wechsel erhalten
- Keine eigene Bildschirmsperre
- Rückkehr direkt zur aktiven Fahrt

## Projekt öffnen
1. Repository herunterladen oder klonen.
2. `RidePilot.xcodeproj` in Xcode öffnen.
3. Unter **Signing & Capabilities** das eigene Development Team auswählen.
4. Bundle Identifier bei Bedarf ändern.
5. Auf einem echten iPhone testen.

## Private Ziele
Die Beispieldaten in `DestinationStore.swift` enthalten absichtlich keine privaten Adressen.
Eigene Ziele lokal ergänzen. Private Wohnadressen nicht in ein öffentliches GitHub-Repository committen.

## Hinweis zur Nutzung
Nachrichten, Dateien oder andere Apps nur im Stillstand bedienen.
